#ifndef WN_H_
#define WN_H_

#include "tree.hpp"

class WordNet{

  public:

    void BuildWordNet(string);
    void HandleTask(string);

  private:
    Tree *root;

};

#endif
